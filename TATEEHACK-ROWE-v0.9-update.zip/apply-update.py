from pathlib import Path
import sys,json,zipfile,hashlib
root=Path.cwd()
with zipfile.ZipFile(sys.argv[1]) as z:
    manifest=json.loads(z.read('update-manifest.json'))
    pending=[]
    for name,hashes in manifest.items():
        path=Path(name)
        if path.is_absolute() or '..' in path.parts or not (name.startswith(('dist/','tests/')) or name=='README.md'):
            raise SystemExit('Unexpected update path: '+name)
        data=z.read(name)
        if hashlib.sha256(data).hexdigest()!=hashes['after']:
            raise SystemExit('Invalid update bytes: '+name)
        dest=root/path
        current=hashlib.sha256(dest.read_bytes()).hexdigest() if dest.exists() else None
        if current not in (hashes['before'],hashes['after']):
            raise SystemExit('File changed since v0.8; refusing overwrite: '+name)
        pending.append((dest,data))
    for dest,data in pending:
        dest.parent.mkdir(parents=True,exist_ok=True)
        dest.write_bytes(data)
print('TATEEHACK v0.9 files applied successfully')
